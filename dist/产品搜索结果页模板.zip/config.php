<?php
// 基础配置
define('ABSPATH', dirname(__FILE__) . '/');
// $TEMPLATE = 'template/default/';

$name = 'en.OFweek.com';
$title = '首页';
$keywords = '关键字';
$description = '描述';
// $islogin = 'false';
// $uid = '123456';

// 重定向
// header('Location: template/default/');
// exit;
?>