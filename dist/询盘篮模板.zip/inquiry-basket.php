<?php
require_once 'config.php';

$class = 'basket nocart nosearch';
$title = 'Inquiried Items';
$keywords = 'Inquiried Items';
$description = 'Inquiried Items';

include 'header.html';
?>

  <div id="main">
    <div class="pagetitle">Inquiried Items</div>
    <div id="js-basket" class="basket">
      <ul>
        <li><a href="#">Mix Laser 588</a> <i></i></li>
        <li><a href="#">JI-02-1X36wrgbpar stage Light</a> <i></i></li>
        <li><a href="#">145W LED Promise Beam Light145W LED Promise Beam Light Mt series LED Magic Balls</a> <i></i></li>
        <li><a href="#">Mt series LED Magic Balls</a> <i></i></li>
      </ul>
      <a href="#" class="btn-send">Send</a>
    </div>
  </div>

<?php include 'footer.html'; ?>